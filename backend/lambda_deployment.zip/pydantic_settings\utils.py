import logging
import os
import types
from pathlib import Path
from typing import Any, _Final, _GenericAlias, get_origin  # type: ignore [attr-defined]

logger = logging.getLogger('pydantic_settings')

_DEBUG_ENV_VAR = 'PYDANTIC_SETTINGS_DEBUG'


def _settings_debug_enabled() -> bool:
    """Whether settings source debugging is enabled via the `PYDANTIC_SETTINGS_DEBUG` env var."""
    return os.environ.get(_DEBUG_ENV_VAR, '').strip().lower() in ('1', 'true', 'yes', 'on')


_PATH_TYPE_LABELS = {
    Path.is_dir: 'directory',
    Path.is_file: 'file',
    Path.is_mount: 'mount point',
    Path.is_symlink: 'symlink',
    Path.is_block_device: 'block device',
    Path.is_char_device: 'char device',
    Path.is_fifo: 'FIFO',
    Path.is_socket: 'socket',
}


def path_type_label(p: Path) -> str:
    """
    Find out what sort of thing a path is.
    """
    assert p.exists(), 'path does not exist'
    for method, name in _PATH_TYPE_LABELS.items():
        if method(p):
            return name

    return 'unknown'  # pragma: no cover


# TODO remove and replace usage by `isinstance(cls, type) and issubclass(cls, class_or_tuple)`
# once we drop support for Python 3.10.
def _lenient_issubclass(cls: Any, class_or_tuple: Any) -> bool:  # pragma: no cover
    try:
        return isinstance(cls, type) and issubclass(cls, class_or_tuple)
    except TypeError:
        if get_origin(cls) is not None:
            # Up until Python 3.10, isinstance(<generic_alias>, type) is True
            # (e.g. list[int])
            return False
        raise


_WithArgsTypes = (_GenericAlias, types.GenericAlias, types.UnionType)
_typing_base: Any = _Final  # pyright: ignore[reportAttributeAccessIssue]
